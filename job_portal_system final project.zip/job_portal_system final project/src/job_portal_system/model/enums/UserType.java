package job_portal_system.model.enums;

public enum UserType {
    Student,Company,Profossor,
   Admin
}
